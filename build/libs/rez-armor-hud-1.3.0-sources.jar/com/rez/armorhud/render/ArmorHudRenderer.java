package com.rez.armorhud.render;

import com.rez.armorhud.config.ModConfig;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.joml.Matrix3x2fStack;

public class ArmorHudRenderer {

    private static final int ITEM_SIZE = 16;
    private static final int GAP = 4;

    public static void render(class_332 drawContext, class_9779 tickCounter) {
        ModConfig config = ModConfig.get();
        if (!config.enabled) {
            return;
        }

        class_310 client = class_310.method_1551();
        class_1657 player = client.field_1724;
        if (player == null) {
            return;
        }

        class_327 textRenderer = client.field_1772;
        if (textRenderer == null) {
            return;
        }

        renderArmorPiece(drawContext, textRenderer,
                player.method_6118(class_1304.field_6169),
                config.helmetX, config.helmetY, config.helmetScale,
                config.showEmptySlots, config.textOnLeft);

        renderArmorPiece(drawContext, textRenderer,
                player.method_6118(class_1304.field_6174),
                config.chestX, config.chestY, config.chestScale,
                config.showEmptySlots, config.textOnLeft);

        renderArmorPiece(drawContext, textRenderer,
                player.method_6118(class_1304.field_6172),
                config.legsX, config.legsY, config.legsScale,
                config.showEmptySlots, config.textOnLeft);

        renderArmorPiece(drawContext, textRenderer,
                player.method_6118(class_1304.field_6166),
                config.bootsX, config.bootsY, config.bootsScale,
                config.showEmptySlots, config.textOnLeft);
    }

    private static void renderArmorPiece(
            class_332 drawContext,
            class_327 textRenderer,
            class_1799 stack,
            int posX,
            int posY,
            float scale,
            boolean showEmpty,
            boolean textOnLeft
    ) {
        if (stack.method_7960() && !showEmpty) {
            return;
        }

        String durabilityText;
        if (stack.method_7960()) {
            durabilityText = "-";
        } else if (stack.method_7963()) {
            durabilityText = Integer.toString(stack.method_7936() - stack.method_7919());
        } else {
            durabilityText = "-";
        }

        int textWidth = textRenderer.method_1727(durabilityText);
        int textHeight = textRenderer.field_2000;

        int localTextX = textOnLeft ? -(textWidth + GAP) : (ITEM_SIZE + GAP);
        int localTextY = (int) Math.round((ITEM_SIZE - textHeight) / 2.0);

        Matrix3x2fStack matrices = drawContext.method_51448();
        matrices.pushMatrix();
        matrices.translate(posX, posY);
        matrices.scale(scale, scale);

        if (!stack.method_7960()) {
            drawContext.method_51427(stack, 0, 0);
        } else {
            drawContext.method_25294(0, 0, ITEM_SIZE, ITEM_SIZE, 0x44000000);
        }

        drawContext.method_51433(textRenderer, durabilityText, localTextX, localTextY, 0xFFFFFFFF, true);

        matrices.popMatrix();
    }
}
